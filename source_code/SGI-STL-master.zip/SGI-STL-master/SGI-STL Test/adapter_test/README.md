## 配接器(adapter)-Code Test
