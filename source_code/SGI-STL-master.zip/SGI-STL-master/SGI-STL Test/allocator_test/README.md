## 配置器(allocator)-Code Test

* [myAllocator](https://github.com/steveLauwh/SGI-STL/tree/master/SGI-STL%20Test/allocator_test/myAllocator)
